function y = sinc(t)
    y = sin(pi * t) ./ (pi * t);
end
