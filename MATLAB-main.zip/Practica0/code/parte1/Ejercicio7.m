[solucion, reales, complejas] = raices([1 2 2], [1 3]);
fprintf('Raíces: ');
disp(solucion);
fprintf('Raíces reales: %d\n', reales);
fprintf('Raíces complejas: %d\n', complejas);